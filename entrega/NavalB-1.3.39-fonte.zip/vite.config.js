import { defineConfig } from 'vite';
import { readFileSync } from 'node:fs';
const pkg = JSON.parse(readFileSync(new URL('./package.json', import.meta.url), 'utf8'));
export default defineConfig({ base: './', define: { __APP_VERSION__: JSON.stringify(pkg.version) }, build: { outDir: 'dist', assetsInlineLimit: 0, chunkSizeWarningLimit: 2000, target: 'es2020' }, server: { host: '0.0.0.0', port: 8080, strictPort: true } });
